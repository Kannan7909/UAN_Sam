define(['ojs/ojcore',"knockout","jquery","appController"], 
    function (oj,ko,$, app) {

        class PartnerReport {
            constructor() {
                var self = this;

            }
        }
        return  PartnerReport;
    }
);