import 'oj-c/input-text';
declare const _default: () => import("preact").JSX.Element;
export default _default;
