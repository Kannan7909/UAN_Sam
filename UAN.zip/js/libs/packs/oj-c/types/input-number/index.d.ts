export { InputNumber } from './input-number';
export { CInputNumberElement } from './input-number';